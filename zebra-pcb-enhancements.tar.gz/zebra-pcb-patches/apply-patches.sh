#!/bin/bash

echo "Zebra-PCB Enhancement Patches"
echo "============================="

# Check if we're in a git repository
if [ ! -d ".git" ]; then
    echo "Error: Not in a git repository. Please run this from your Zebra-PCB repository root."
    exit 1
fi

# Check if we're on the xzz-pcb branch
CURRENT_BRANCH=$(git branch --show-current)
if [ "$CURRENT_BRANCH" != "xzz-pcb" ]; then
    echo "Warning: Not on xzz-pcb branch (currently on: $CURRENT_BRANCH)"
    echo "Switching to xzz-pcb branch..."
    git checkout xzz-pcb
fi

echo "Applying enhancement patches..."

# Apply patches in order
echo "1. Applying Windows build system enhancements..."
if git apply 0001-Enhanced-Windows-build-system-with-static-linking-su.patch; then
    echo "   ✅ Patch 1 applied successfully"
else
    echo "   ❌ Failed to apply patch 1"
    exit 1
fi

echo "2. Applying documentation and setup scripts..."
if git apply 0002-Add-enhanced-repository-documentation-and-setup-scri.patch; then
    echo "   ✅ Patch 2 applied successfully"
else
    echo "   ❌ Failed to apply patch 2"
    exit 1
fi

echo "3. Applying migration instructions..."
if git apply 0003-Add-migration-instructions-for-new-repository-setup.patch; then
    echo "   ✅ Patch 3 applied successfully"
else
    echo "   ❌ Failed to apply patch 3"
    exit 1
fi

echo ""
echo "✅ All patches applied successfully!"
echo ""
echo "Next steps:"
echo "1. Review the changes: git status"
echo "2. Commit the changes: git add . && git commit -m 'Apply Zebra-PCB enhancements'"
echo "3. Push to repository: git push origin xzz-pcb"
echo "4. Set xzz-pcb as default branch in GitHub settings"
echo ""
echo "Enhanced features:"
echo "- Windows static build support (MSYS2 + cross-compilation)"
echo "- Memory leak fixes and 64-bit Windows compatibility"
echo "- Comprehensive build documentation"
echo "- Portable Windows executable generation (~5.2MB)"
echo ""
echo "See README_ENHANCED.md for complete feature overview."